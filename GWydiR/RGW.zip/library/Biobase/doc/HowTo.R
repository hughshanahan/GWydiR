### R code from vignette source 'HowTo.Rnw'

###################################################
### code chunk number 1: HowTo.Rnw:86-87
###################################################
sessionInfo()


